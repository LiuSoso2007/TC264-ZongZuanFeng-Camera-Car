Encoder.o :	../code/Encoder.c
../code/Encoder.c :
Encoder.o :	..\code\Encoder.h
..\code\Encoder.h :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_headfile.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_headfile.h" :
Encoder.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
Encoder.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
Encoder.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
Encoder.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
Encoder.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
Encoder.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h" :
Encoder.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
Encoder.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_typedef.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_typedef.h" :
Encoder.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_clock.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_clock.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_debug.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_debug.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_interrupt.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_interrupt.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_fifo.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_fifo.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_font.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_font.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_function.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_common\zf_common_function.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\user\isr_config.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\user\isr_config.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_adc.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_adc.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_delay.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_delay.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_dma.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_dma.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_exti.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_exti.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_encoder.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_encoder.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_exti.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_exti.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_flash.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_flash.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_gpio.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_gpio.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_pit.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_pit.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_pwm.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_pwm.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_soft_iic.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_soft_iic.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_spi.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_spi.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_soft_spi.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_soft_spi.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_uart.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_uart.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_timer.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_timer.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_absolute_encoder.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_absolute_encoder.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_ble6a20.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_ble6a20.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_bluetooth_ch9141.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_bluetooth_ch9141.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_gnss.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_gnss.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_camera.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_camera.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_uart.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_driver\zf_driver_uart.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_type.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_type.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_dl1a.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_dl1a.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_dl1b.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_dl1b.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_icm20602.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_icm20602.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_imu660ra.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_imu660ra.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_imu660rb.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_imu660rb.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_imu660rx.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_imu660rx.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_imu660rc.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_imu660rc.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_imu963ra.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_imu963ra.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_ips114.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_ips114.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_ips200.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_ips200.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_ips200pro.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_ips200pro.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_key.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_key.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_menc15a.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_menc15a.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_mpu6050.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_mpu6050.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_mt9v03x.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_mt9v03x.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_oled.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_oled.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_ov7725.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_ov7725.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_scc8660.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_scc8660.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_tft180.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_tft180.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_tsl1401.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_tsl1401.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_uart_receiver.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_uart_receiver.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_virtual_oscilloscope.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_virtual_oscilloscope.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_wifi_uart.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_wifi_uart.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_wifi_spi.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_wifi_spi.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_wireless_uart.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_device\zf_device_wireless_uart.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_components\seekfree_assistant.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_components\seekfree_assistant.h" :
Encoder.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_components\seekfree_assistant_interface.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\zf_components\seekfree_assistant_interface.h" :
