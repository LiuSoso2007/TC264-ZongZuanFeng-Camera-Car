/******************************************************************************
 * PID.c - PD舵机 + PI电机
 ******************************************************************************/
#include "PID.h"
#include "Servo.h"

/* ---- PD ---- */
#define PD_ERR_DEAD_ZONE 0.0f  /* Err死区边界，范围内舵机回中。 */
#define SERVO_MIN_SIDE_WEIGHT  0.85f  /* 100方向基础权重，负向误差越大时再按比例增强。 */
#define SERVO_MAX_SIDE_WEIGHT  0.85f  /* 175方向固定权重，以1为归一化基准。 */
static float   s_pd_out = 0.0f, s_pd_offset = 0.0f;
static float   s_pd_err0 = 0.0f, s_pd_err1 = 0.0f;

void PD_Update(float Kp, float Kd, float err)
{
    s_pd_err1 = s_pd_err0;
    s_pd_err0 = err;

    //以下是计算pd
    if(s_pd_err0 > 0 && s_pd_err0 < 50 )
        s_pd_offset = Kp * s_pd_err0 + (Kd  * (50-  s_pd_err0 )/50) * (s_pd_err0 - s_pd_err1);
    else if(s_pd_err0 < 0 && s_pd_err0 > -50 )
        s_pd_offset = Kp * s_pd_err0 + (Kd  * (50-(-s_pd_err0))/50) * (s_pd_err0 - s_pd_err1);
    else  s_pd_offset = Kp * s_pd_err0;

    //以下是计算偏移
    if (s_pd_offset < -8.0f)
        s_pd_offset *= SERVO_MIN_SIDE_WEIGHT * (1+1.0*(-8-s_pd_offset)/33);  //左偏增大
    else if(s_pd_offset > 8.0f)
        s_pd_offset *= SERVO_MAX_SIDE_WEIGHT * (1+1.0*(-8+s_pd_offset)/30);   //右偏增大
    else
        s_pd_offset *= SERVO_MAX_SIDE_WEIGHT;

    s_pd_out = (float)SERVO_CENTER_ANGLE + s_pd_offset;
    if (s_pd_out > (float)SERVO_MAX_ANGLE) s_pd_out = (float)SERVO_MAX_ANGLE;
    if (s_pd_out < (float)SERVO_MIN_ANGLE) s_pd_out = (float)SERVO_MIN_ANGLE;

    if (err >= -PD_ERR_DEAD_ZONE && err <= PD_ERR_DEAD_ZONE)
        Servo_SetAngleDeg(SERVO_CENTER_ANGLE);
    else
        Servo_SetAngleDeg((uint8_t)s_pd_out);
}

/* ---- PI ---- */
void PI_Init(PI_t *pi, float kp, float ki, int16_t min_speed)
{
    pi->Kp          = kp;
    pi->Ki          = ki;
    pi->MinSpeed    = min_speed;
    pi->LastSpdErr  = 0;
    pi->Output      = 0.0f;
    pi->TargetSpeed = 0;
    pi->TargetBias  = 0;
}

int8_t PI_Update(PI_t *pi, float pos_err, int16_t act_spd, int16_t str_spd)
{
    int16_t abs_err;
    if (pos_err < 0)
        abs_err = (int16_t)(-pos_err);
    else
        abs_err = (int16_t)pos_err;
    if (abs_err > 100) abs_err = 100;

    int16_t target;
    if (abs_err <= 2)
        target = str_spd;
    else
        target = pi->MinSpeed + (int16_t)((int32_t)(str_spd - pi->MinSpeed)
                                          * (100 - abs_err) / 100);
    target += pi->TargetBias;
    pi->TargetSpeed = target;

    int16_t err = target - act_spd;
    float   inc = pi->Kp * (float)(err - pi->LastSpdErr)
                + pi->Ki * (float)err;
    pi->Output += inc;
    pi->LastSpdErr = err;

    if (pi->Output > PI_OUT_MAX) pi->Output = PI_OUT_MAX;
    if (pi->Output < PI_OUT_MIN) pi->Output = PI_OUT_MIN;
    return (int8_t)pi->Output;
}
