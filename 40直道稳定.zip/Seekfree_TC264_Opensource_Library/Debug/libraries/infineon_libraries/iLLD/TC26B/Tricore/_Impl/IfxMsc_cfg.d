IfxMsc_cfg.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.c :
IfxMsc_cfg.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxMsc_cfg.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxMsc_cfg.h :
IfxMsc_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxMsc_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxMsc_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxMsc_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxMsc_cfg.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxMsc_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxMsc_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxMsc_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMsc_reg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMsc_reg.h" :
IfxMsc_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMsc_regdef.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMsc_regdef.h" :
IfxMsc_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
