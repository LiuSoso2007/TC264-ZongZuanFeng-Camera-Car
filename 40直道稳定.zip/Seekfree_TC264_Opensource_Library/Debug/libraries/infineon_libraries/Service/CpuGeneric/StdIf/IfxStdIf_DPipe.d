IfxStdIf_DPipe.o :	../libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.c
../libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.c :
IfxStdIf_DPipe.o :	..\libraries\infineon_libraries\Service\CpuGeneric\StdIf\IfxStdIf_DPipe.h
..\libraries\infineon_libraries\Service\CpuGeneric\StdIf\IfxStdIf_DPipe.h :
IfxStdIf_DPipe.o :	..\libraries\infineon_libraries\Service\CpuGeneric\StdIf\IfxStdIf.h
..\libraries\infineon_libraries\Service\CpuGeneric\StdIf\IfxStdIf.h :
IfxStdIf_DPipe.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxStdIf_DPipe.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxStdIf_DPipe.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxStdIf_DPipe.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxStdIf_DPipe.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxStdIf_DPipe.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxStdIf_DPipe.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxStdIf_DPipe.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
IfxStdIf_DPipe.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
IfxStdIf_DPipe.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
IfxStdIf_DPipe.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
