IfxScu_cfg.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.c :
IfxScu_cfg.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxScu_cfg.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxScu_cfg.h :
IfxScu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxScu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
IfxScu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
