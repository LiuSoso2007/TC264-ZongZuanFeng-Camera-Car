IfxCpu_cfg.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.c :
IfxCpu_cfg.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxCpu_cfg.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxCpu_cfg.h :
IfxCpu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxCpu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxCpu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxCpu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxCpu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxCpu_cfg.o :	"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\Developer Center Launcher\AURIX-Studio-1.10.36\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxCpu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxCpu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxCpu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxCpu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
IfxCpu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
IfxCpu_cfg.o :	"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\durian\\Desktop\\TC264\\shexiangtou\\Seekfree_TC264_Opensource_Library\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
